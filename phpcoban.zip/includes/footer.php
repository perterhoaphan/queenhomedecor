<footer class="page-footer">

        <div class="footer-nav">
            <div class="container clearfix">
                <div class="col-md-4">
                <div class="footer-nav__col footer-nav__col--info">
                    <div class="footer-nav__heading">Thông tin</div>
                    <ul class="footer-nav__list">
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Thương Hiệu</a>
                        </li>
                        
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Dịch vụ khách hàng</a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Quyền riêng tư &amp; cookies</a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Site map</a>
                        </li>
                    </ul>
                </div>
                </div>
                <div class="col-md-4">
                <div class="footer-nav__col footer-nav__col--account">
                    <div class="footer-nav__heading">Tài khoản của bạn</div>
                    <ul class="footer-nav__list">
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Đăng nhập</a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Đăng ký</a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Xem giỏ hàng</a>
                        </li>
                       
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Theo dõi đơn hàng</a>
                        </li>
                        <li class="footer-nav__item">
                            <a href="#" class="footer-nav__link">Cập nhật Thông tin</a>
                        </li>
                    </ul>
                </div>
                </div>
                <div class="col-md-4">
                <div class="footer-nav__col footer-nav__col--contacts">
                    <div class="footer-nav__heading">CHI TIẾT LIÊN HỆ</div>
                    <address class="address">
                        Điện biên phủ - Đà nẵng.
                        
                    </address>
                    <div class="phone">
                        Điện thoại:
                        <a class="phone__number" href="tel:0906558604">0906558604</a>
                    </div>
                    <div class="email">
                        Email:
                        <a href="mailto:peter.hoaphan@gmail.com" class="email__addr">peter.hoaphan@gmail.com</a>
                    </div>
                </div>
                </div>


                
                
               
            </div>
        </div>



    </footer>
